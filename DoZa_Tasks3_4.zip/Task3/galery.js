class Galery 
{
    constructor() {
        this.imgs = [];
    }

    addImgs(url){
        let obj = this;
        fetch(url)
            .then(function(resp) {
                return resp.json();
            })
            .then(function(imgs) {
                obj.imgs = JSON.parse(JSON.stringify(imgs));
                obj.displayNoModal();
                document.body.appendChild(document.createElement("hr"));
                obj.displayModal();
            });
    }

    displayNoModal() {
        let header = document.createElement("div");
        header.innerText = "Обычное открытие";
        let div = document.createElement("div");
        div.setAttribute("id", "galery");
        this.imgs.forEach(el => {
            let newA = document.createElement("a");
            newA.href = el.max;
            newA.target = "_blank";
            let newImg = document.createElement("img");
            newImg.src = el.min;
            newA.appendChild(newImg);
            div.appendChild(newA);
        });
        document.body.appendChild(header);
        document.body.appendChild(div);
    }

    displayModal() {
        let header = document.createElement("div");
        header.innerText = "Модальное открытие";
        let div = document.createElement("div");
        div.setAttribute("id", "galeryModal");
        let span = document.createElement("span");
        span.innerHTML = "&times;";
        span.style.color = "white";
        span.style.position = "absolute";
        span.style.top = "5px";
        span.style.right = "25px";
        span.style.fontSize = "35px";
        span.style.fontWeight = "bold";
        span.addEventListener("click",function(){
            document.getElementById("modalWindow").style.display = "none";
        });

        let imgModal = document.createElement("img");
        imgModal.setAttribute("id", "fullImage");
        imgModal.style.maxWidth = "75%";

        let divModalContent = document.createElement("div");
        divModalContent.style.position = "relative";
        divModalContent.style.margin = "auto";
        divModalContent.style.padding = "0";
        divModalContent.style.textAlign = "center";
        divModalContent.style.maxWidth = "1200px";
        divModalContent.appendChild(imgModal);

        let divModal = document.createElement("div");
        divModal.setAttribute("id","modalWindow");
        divModal.style.display = "none";
        divModal.style.position = "fixed";
        divModal.style.zIndex = "1";
        divModal.style.paddingTop = "50px";
        divModal.style.left = "0";
        divModal.style.top = "0";
        divModal.style.width = "100%";
        divModal.style.height = "100%";
        divModal.style.overflow = "auto";
        divModal.style.backgroundColor = "black";

        divModal.appendChild(span);
        divModal.appendChild(divModalContent);

        this.imgs.forEach(el => {
            let newImg = document.createElement("img");
            newImg.src = el.min;
            newImg.addEventListener("click",function(){
                document.getElementById("fullImage").src = el.max;
                document.getElementById("modalWindow").style.display = "block";
            });
            div.appendChild(newImg);
        });
        div.appendChild(divModal);

        document.body.appendChild(header);
        document.body.appendChild(div);
    }
}